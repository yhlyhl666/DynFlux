import torch
import torch.nn as nn
import torch.nn.functional as F

from ...subNets import BertTextEncoder
from ...subNets.transformers_encoder.transformer import TransformerEncoder
from ...singleTask.model.router import router


# ──────────────────────────────
# Attention Pooling（Embedding-Space）
# ──────────────────────────────
class AttentionPool(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.w = nn.Linear(dim, 1, bias=False)

    def forward(self, x):              # x: (T, B, D)
        a = torch.softmax(self.w(x), dim=0)   # (T,B,1)
        g = (a * x).sum(dim=0)                # (B,D)
        return g


# ──────────────────────────────
# RAG ①：环形 Memory Bank
# ──────────────────────────────
class MemoryBank(nn.Module):
    def __init__(self, dim, bank_size=20000):
        super().__init__()
        self.register_buffer('keys', torch.zeros(bank_size, dim))
        self.ptr = 0
        self.bank_size = bank_size
        self.dim = dim
        self.filled = 0                   # 已写入样本数

    @torch.no_grad()
    def update(self, feats):             # feats: (B,D)
        B = feats.size(0)
        feats = F.normalize(feats, dim=-1)
        if B >= self.bank_size:          # 若 batch 超过 bank，随机采 bank_size 个
            feats = feats[: self.bank_size]
            B = self.bank_size
        idx = torch.arange(B, device=feats.device) + self.ptr
        idx = idx % self.bank_size
        self.keys[idx] = feats
        self.ptr = (self.ptr + B) % self.bank_size
        self.filled = min(self.filled + B, self.bank_size)

    def ready(self, k_pos, k_neg):
        return self.filled >= (k_pos + k_neg)


# ──────────────────────────────
# RAG ②：检索 Top-K / Bottom-L
# ──────────────────────────────
class JointRetriever(nn.Module):
    def __init__(self, topk_pos=20, topk_neg=20):
        super().__init__()
        self.kp = topk_pos
        self.kn = topk_neg

    def forward(self, q, bank_keys):     # q:(B,D)   bank:(N,D)
        q = F.normalize(q, dim=-1)
        sim = torch.matmul(q, bank_keys.t())                # (B,N)
        # Top-K 正样本（最相似）
        pos_score, pos_idx = sim.topk(self.kp, dim=-1, largest=True)
        # Bottom-L 负样本（最不相似）
        neg_score, neg_idx = (-sim).topk(self.kn, dim=-1, largest=True)
        B, D = q.size()
        k_pos = bank_keys[pos_idx.view(-1)].view(B, self.kp, D)   # (B,Kp,D)
        k_neg = bank_keys[neg_idx.view(-1)].view(B, self.kn, D)   # (B,Kn,D)
        return k_pos, k_neg


# ──────────────────────────────
# RAG ③：Bipolar Attention（向量版）
# ──────────────────────────────
class BipolarAttentionVec(nn.Module):
    def __init__(self, dim, alpha=0.7):
        super().__init__()
        self.scale = dim ** 0.5
        self.alpha = nn.Parameter(torch.tensor(alpha))

    def forward(self, q, k_pos, k_neg):        # q:(B,D)  k_pos:(B,K,D)
        # 正注意
        att_p = torch.softmax(torch.einsum('bd,bkd->bk', q, k_pos) / self.scale, dim=-1)  # (B,K)
        v_pos = torch.einsum('bk,bkd->bd', att_p, k_pos)
        # 负注意
        att_n = torch.softmax(torch.einsum('bd,bkd->bk', q, k_neg) / self.scale, dim=-1)  # (B,L)
        v_neg = torch.einsum('bk,bkd->bd', att_n, k_neg)
        # 融合
        q_aug = q + self.alpha * v_pos + (1 - self.alpha) * v_neg
        return q_aug


# ──────────────────────────────
#           EMOE (with RAG)
# ──────────────────────────────
class EMOE(nn.Module):
    def __init__(self, args):
        super().__init__()

        # ===== 文本编码（BERT，可选） =====
        if args.use_bert:
            self.text_model = BertTextEncoder(use_finetune=args.use_finetune,
                                              transformers=args.transformers,
                                              pretrained=args.pretrained)
        self.use_bert = args.use_bert

        # ===== 数据集 & 超参 =====
        dst_feature_dims, nheads = args.dst_feature_dim_nheads
        if args.dataset_name == 'mosi':
            self.len_l, self.len_v, self.len_a = (50, 50, 50) if args.need_data_aligned else (50, 500, 375)
        elif args.dataset_name == 'mosei':
            self.len_l, self.len_v, self.len_a = (50, 50, 50) if args.need_data_aligned else (50, 500, 500)
        else:
            raise ValueError(f"Unknown dataset {args.dataset_name}")

        self.aligned = args.need_data_aligned
        self.orig_d_l, self.orig_d_a, self.orig_d_v = args.feature_dims
        self.d_l = self.d_a = self.d_v = dst_feature_dims
        self.num_heads = nheads
        self.layers = args.nlevels
        self.attn_dropout, self.attn_dropout_a, self.attn_dropout_v = args.attn_dropout, args.attn_dropout_a, args.attn_dropout_v
        self.relu_dropout, self.embed_dropout, self.res_dropout = args.relu_dropout, args.embed_dropout, args.res_dropout
        self.output_dropout, self.text_dropout = args.output_dropout, args.text_dropout
        self.attn_mask = args.attn_mask
        self.fusion_method = args.fusion_method
        output_dim = 1
        self.args = args

        # ===== Conv1d 投影 =====
        self.proj_l = nn.Conv1d(self.orig_d_l, self.d_l, kernel_size=args.conv1d_kernel_size_l, padding=0, bias=False)
        self.proj_a = nn.Conv1d(self.orig_d_a, self.d_a, kernel_size=args.conv1d_kernel_size_a, padding=0, bias=False)
        self.proj_v = nn.Conv1d(self.orig_d_v, self.d_v, kernel_size=args.conv1d_kernel_size_v, padding=0, bias=False)

        # 1×1 Conv
        self.encoder_c = nn.Conv1d(self.d_l, self.d_l, kernel_size=1, padding=0, bias=False)
        self.encoder_l = nn.Conv1d(self.d_l, self.d_l, kernel_size=1, padding=0, bias=False)
        self.encoder_v = nn.Conv1d(self.d_v, self.d_v, kernel_size=1, padding=0, bias=False)
        self.encoder_a = nn.Conv1d(self.d_a, self.d_a, kernel_size=1, padding=0, bias=False)

        # Transformer
        self.self_attentions_l = self._build_transformer('l')
        self.self_attentions_v = self._build_transformer('v')
        self.self_attentions_a = self._build_transformer('a')

        # Attention Pooling
        self.pool_l = AttentionPool(self.d_l)
        self.pool_a = AttentionPool(self.d_a)
        self.pool_v = AttentionPool(self.d_v)

        # ===== RAG 组件 =====
        kp = getattr(args, 'rag_kp', 20)
        kn = getattr(args, 'rag_kn', 20)
        bank_size = getattr(args, 'rag_bank_size', 20000)
        alpha = getattr(args, 'rag_alpha', 0.7)

        self.mem_bank = MemoryBank(self.d_l, bank_size=bank_size)
        self.retriever = JointRetriever(topk_pos=kp, topk_neg=kn)
        self.bip_attn_l = BipolarAttentionVec(self.d_l, alpha=alpha)    # 仅增强文本向量

        # ===== 单模态 Heads =====
        self.proj1_l = nn.Linear(self.d_l, self.d_l); self.proj2_l = nn.Linear(self.d_l, self.d_l)
        self.out_layer_l = nn.Linear(self.d_l, output_dim)

        self.proj1_v = nn.Linear(self.d_l, self.d_l); self.proj2_v = nn.Linear(self.d_l, self.d_l)
        self.out_layer_v = nn.Linear(self.d_l, output_dim)

        self.proj1_a = nn.Linear(self.d_l, self.d_l); self.proj2_a = nn.Linear(self.d_l, self.d_l)
        self.out_layer_a = nn.Linear(self.d_l, output_dim)

        # ===== 融合 Head =====
        fuse_in = self.d_l if self.fusion_method == "sum" else self.d_l * 3
        self.proj1_c = nn.Linear(fuse_in, fuse_in)
        self.proj2_c = nn.Linear(fuse_in, fuse_in)
        self.out_layer_c = nn.Linear(fuse_in, output_dim)

        # Router & 对齐
        flat_dim = self.orig_d_l * self.len_l + self.orig_d_a * self.len_l + self.orig_d_v * self.len_l
        self.Router = router(flat_dim, 3, self.args.temperature)
        self.transfer_a_ali = nn.Linear(self.len_a, self.len_l)
        self.transfer_v_ali = nn.Linear(self.len_v, self.len_l)

    # ───────────────────────
    def _build_transformer(self, t):
        if t == 'l':   embed_dim, attn_dropout = self.d_l, self.attn_dropout
        elif t == 'a': embed_dim, attn_dropout = self.d_a, self.attn_dropout_a
        else:          embed_dim, attn_dropout = self.d_v, self.attn_dropout_v
        return TransformerEncoder(embed_dim=embed_dim,
                                  num_heads=self.num_heads,
                                  layers=self.layers,
                                  attn_dropout=attn_dropout,
                                  relu_dropout=self.relu_dropout,
                                  res_dropout=self.res_dropout,
                                  embed_dropout=self.embed_dropout,
                                  attn_mask=self.attn_mask)

    # ───────────────────────
    def _mlp_head(self, x, p1, p2, out):
        h = p2(F.dropout(F.relu(p1(x), inplace=True),
                         p=self.output_dropout, training=self.training))
        h = h + x
        return out(h), h

    # ───────────────────────
    def forward(self, text, audio, video):
        # 1) 文本编码
        if self.use_bert:
            text = self.text_model(text)                    # (B,T,768)

        # 2) 转置为 (B,C,L)
        x_l = F.dropout(text.transpose(1, 2), p=self.text_dropout, training=self.training)
        x_a = audio.transpose(1, 2)
        x_v = video.transpose(1, 2)

        # 3) 若非对齐，插值
        if not self.aligned:
            audio_ = self.transfer_a_ali(audio.permute(0,2,1)).permute(0,2,1)
            video_ = self.transfer_v_ali(video.permute(0,2,1)).permute(0,2,1)
            m_i = torch.cat((text, video_, audio_), dim=2)
        else:
            m_i = torch.cat((text, video, audio), dim=2)
        m_w = self.Router(m_i)                               # (B,3)

        # 4) Conv1d 投影
        proj_x_l = x_l if self.orig_d_l == self.d_l else self.proj_l(x_l)
        proj_x_a = x_a if self.orig_d_a == self.d_a else self.proj_a(x_a)
        proj_x_v = x_v if self.orig_d_v == self.d_v else self.proj_v(x_v)

        # 5) 1×1 Conv
        c_l = self.encoder_c(proj_x_l);  c_l = c_l.permute(2,0,1)   # (L,B,D)
        c_a = self.encoder_c(proj_x_a);  c_a = c_a.permute(2,0,1)
        c_v = self.encoder_c(proj_x_v);  c_v = c_v.permute(2,0,1)

        # 6) Transformer
        c_l_att = self.self_attentions_l(c_l)[0] if isinstance(self.self_attentions_l(c_l), tuple) else self.self_attentions_l(c_l)
        c_a_att = self.self_attentions_a(c_a)[0] if isinstance(self.self_attentions_a(c_a), tuple) else self.self_attentions_a(c_a)
        c_v_att = self.self_attentions_v(c_v)[0] if isinstance(self.self_attentions_v(c_v), tuple) else self.self_attentions_v(c_v)

        # 7) Attention Pooling → (B,D)
        c_l_att = self.pool_l(c_l_att)
        c_a_att = self.pool_a(c_a_att)
        c_v_att = self.pool_v(c_v_att)

        # ────────────────  RAG  ────────────────
        # 7.1 更新 MemoryBank（detach，避免反传）
        with torch.no_grad():
            self.mem_bank.update(c_l_att.detach())

        # 7.2 若 bank 已准备就绪，执行检索并用 BipolarAttentionVec 增强文本向量
        if self.mem_bank.ready(self.retriever.kp, self.retriever.kn):
            k_pos, k_neg = self.retriever(c_l_att, self.mem_bank.keys[:self.mem_bank.filled])
            c_l_att = self.bip_attn_l(c_l_att, k_pos, k_neg)
        # ──────────────── /RAG ────────────────

        # 8) 单模态 MLP
        logits_l, l_proj = self._mlp_head(c_l_att, self.proj1_l, self.proj2_l, self.out_layer_l)
        logits_v, v_proj = self._mlp_head(c_v_att, self.proj1_v, self.proj2_v, self.out_layer_v)
        logits_a, a_proj = self._mlp_head(c_a_att, self.proj1_a, self.proj2_a, self.out_layer_a)

        # 9) 融合
        if self.fusion_method == "sum":
            c_fusion = (c_l_att * m_w[:, 0:1] +
                        c_v_att * m_w[:, 1:2] +
                        c_a_att * m_w[:, 2:3])
        else:  # concat
            c_fusion = torch.cat([c_l_att * m_w[:, 0:1],
                                  c_v_att * m_w[:, 1:2],
                                  c_a_att * m_w[:, 2:3]], dim=-1) * 3

        c_proj = self.proj2_c(F.dropout(F.relu(self.proj1_c(c_fusion), inplace=True),
                                        p=self.output_dropout, training=self.training))
        c_proj = c_proj + c_fusion
        logits_c = self.out_layer_c(c_proj)

        # 10) 输出
        return {
            'logits_c': logits_c,
            'logits_l': logits_l,
            'logits_v': logits_v,
            'logits_a': logits_a,
            'channel_weight': m_w,
            'c_proj': c_proj,
            'l_proj': l_proj,
            'v_proj': v_proj,
            'a_proj': a_proj,
            'c_fea': c_fusion,
        }
