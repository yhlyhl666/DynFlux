import torch
import torch.nn as nn
import torch.nn.functional as F
try:
    import torch_geometric.nn as gnn
    from torch_geometric.data import Data, Batch
    HAS_TORCH_GEOMETRIC = True
except ImportError:
    HAS_TORCH_GEOMETRIC = False
    print("Warning: torch_geometric not found. Using alternative implementation.")

from ...subNets import BertTextEncoder
from ...subNets.transformers_encoder.transformer import TransformerEncoder
from ...singleTask.model.router import router


class AttentionPool(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.w = nn.Linear(dim, 1, bias=False)

    def forward(self, x):
        a = torch.softmax(self.w(x), dim=0)
        g = (a * x).sum(dim=0)
        return g


class GuidedAttentionPool(nn.Module):
    def __init__(self, original_dim, intervention_dim):
        super().__init__()
        self.attention_projector = nn.Linear(original_dim, 1, bias=False)
        
        self.intervention_adjuster = nn.Sequential(
            nn.Linear(intervention_dim, (intervention_dim + 1) // 2),
            nn.ReLU(),
            nn.Linear((intervention_dim + 1) // 2, 1)
        )
        
        self.gate = nn.Linear(intervention_dim, 1)
        with torch.no_grad():
            self.gate.bias.fill_(-3.0)

    def forward(self, x, intervention_signal):
        raw_attn_scores = self.attention_projector(x)
        
        attn_adjustment = self.intervention_adjuster(intervention_signal)
        gate = torch.sigmoid(self.gate(intervention_signal))

        final_attn_scores = raw_attn_scores + gate * attn_adjustment
        
        attn_weights = torch.softmax(final_attn_scores, dim=0)
        pooled_feature = (attn_weights * x).sum(dim=0)
        
        return pooled_feature



class FusionWeightModulator(nn.Module):
    def __init__(self, graph_hidden_dim, num_modalities=3):
        super().__init__()
        self.num_modalities = num_modalities

        self.pool = AttentionPool(graph_hidden_dim)
        
        self.context_processor = nn.Sequential(
            nn.Linear(graph_hidden_dim * num_modalities, graph_hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(graph_hidden_dim, graph_hidden_dim // 2)
        )
        
        self.weight_adjuster = nn.Sequential(
            nn.Linear(graph_hidden_dim // 2, num_modalities * 2)
        )
        
        with torch.no_grad():
            self.weight_adjuster[-1].bias[num_modalities:].fill_(-3.0)
        
        self.confidence_predictor = nn.Sequential(
            nn.Linear(graph_hidden_dim // 2, 1),
            nn.Sigmoid()
        )
        
        self.dropout = nn.Dropout(0.2)
    
    def forward(self, original_weights, temporal_intervention_signals):
        pooled_signals = [self.pool(sig) for sig in temporal_intervention_signals]

        global_context = torch.cat(pooled_signals, dim=-1)
        
        processed_context = self.context_processor(global_context)
        
        adjustment_params = self.weight_adjuster(processed_context)
        delta, gate = torch.chunk(adjustment_params, 2, dim=-1)
        
        confidence = self.confidence_predictor(processed_context)
        
        delta = torch.tanh(delta) * 0.2
        
        gate = torch.sigmoid(gate)
        
        adjusted_weights = original_weights + gate * self.dropout(delta)
        
        modulated_weights = F.softmax(adjusted_weights / 0.1, dim=-1)
        
        return modulated_weights, confidence




class ConsensusDisagreementGraphBuilder(nn.Module):
    def __init__(self, d_l, d_a, d_v, topk=5, threshold=0.3, temporal_topk=3, disc_mode='orc'):
        super().__init__()
        self.topk = topk
        self.threshold = threshold
        self.temporal_topk = temporal_topk
        self.disc_mode = disc_mode

        self.W_l2a_cons = nn.Linear(d_l, d_l)
        self.W_l2v_cons = nn.Linear(d_l, d_l)
        self.W_a2l_cons = nn.Linear(d_a, d_a)
        self.W_a2v_cons = nn.Linear(d_a, d_a)
        self.W_v2l_cons = nn.Linear(d_v, d_v)
        self.W_v2a_cons = nn.Linear(d_v, d_v)

        self.W_l2a_disc = nn.Linear(d_l, d_l)
        self.W_l2v_disc = nn.Linear(d_l, d_l)
        self.W_a2l_disc = nn.Linear(d_a, d_a)
        self.W_a2v_disc = nn.Linear(d_a, d_a)
        self.W_v2l_disc = nn.Linear(d_v, d_v)
        self.W_v2a_disc = nn.Linear(d_v, d_v)
        


    def compute_consensus_kernel(self, h1, h2, W):
        h1_proj = W(h1)
        h2_proj = W(h2)

        h1_proj_norm = F.normalize(h1_proj, dim=-1)
        h2_proj_norm = F.normalize(h2_proj, dim=-1)

        sqdist = self._pairwise_sq_dist(h1_proj_norm, h2_proj_norm)

        K = self._rbf_kernel_from_sqdist(sqdist)
        return K




    def _pairwise_sq_dist(self, A, B):
        A2 = (A * A).sum(dim=-1, keepdim=True)
        B2 = (B * B).sum(dim=-1).unsqueeze(-2)
        AB = torch.matmul(A, B.transpose(-2, -1))
        return (A2 + B2 - 2 * AB).clamp_min(0.0)

    def _rbf_kernel_from_sqdist(self, sqdist, sigma2=None, eps=1e-6):
        if sigma2 is None:
            med = torch.median(sqdist.detach()) + eps
            sigma2 = med
        return torch.exp(-sqdist / (2.0 * sigma2))

    def compute_mmd_discrepancy(self, A, B):
        sqdist = self._pairwise_sq_dist(A, B)
        K = self._rbf_kernel_from_sqdist(sqdist)
        disagreement_score = torch.sqrt((1.0 - K).clamp_min(0.0))
        return disagreement_score 


    def compute_mmd_pairwise(self, A, B, eps=1e-6):
        A = F.normalize(A, dim=-1)
        B = F.normalize(B, dim=-1)
        sqdist = self._pairwise_sq_dist(A, B)  
        med = torch.median(sqdist.detach()) + eps
        K = torch.exp(-sqdist / (2.0 * med))
        mmd2 = (2.0 - 2.0 * K).clamp_min(0.0)
        return torch.sqrt(mmd2)

    def compute_disagreement(self, x_src, x_tgt, W_src_to_tgt_disc, src_type, tgt_type):
        x_src_proj = W_src_to_tgt_disc(x_src)
        x_tgt_proj = W_src_to_tgt_disc(x_tgt)

        return self.compute_mmd_discrepancy(x_src_proj, x_tgt_proj)





    def _build_edge_index_from_edges(self, edges, B, T_l, T_a, T_v, device):
        edge_index_dict = {}
        edge_weight_dict = {}

        edge_types = [
            ('l', 'cons', 'a'), ('l', 'cons', 'v'), ('a', 'cons', 'l'),
            ('a', 'cons', 'v'), ('v', 'cons', 'l'), ('v', 'cons', 'a'),
            ('l', 'disc', 'a'), ('l', 'disc', 'v'), ('a', 'disc', 'l'),
            ('a', 'disc', 'v'), ('v', 'disc', 'l'), ('v', 'disc', 'a'),
            ('l', 'temp', 'l'), ('a', 'temp', 'a'), ('v', 'temp', 'v')
        ]

        for edge_type in edge_types:
            edge_index_dict[edge_type] = [[], []]
            edge_weight_dict[edge_type] = []

        for edge in edges:
            b, src_type, src_idx, dst_type, dst_idx, weight, edge_type = edge

            if src_type == 'l':
                global_src = b * T_l + src_idx
            elif src_type == 'a':
                global_src = b * T_a + src_idx
            else:
                global_src = b * T_v + src_idx

            if dst_type == 'l':
                global_dst = b * T_l + dst_idx
            elif dst_type == 'a':
                global_dst = b * T_a + dst_idx
            else:
                global_dst = b * T_v + dst_idx

            edge_key = (src_type, edge_type, dst_type)

            if edge_key in edge_index_dict:
                edge_index_dict[edge_key][0].append(global_src)
                edge_index_dict[edge_key][1].append(global_dst)
                edge_weight_dict[edge_key].append(weight)

        for key in edge_index_dict:
            if edge_index_dict[key][0]:
                edge_index_dict[key] = torch.tensor(edge_index_dict[key], dtype=torch.long, device=device)
                edge_weight_dict[key] = torch.tensor(edge_weight_dict[key], dtype=torch.float, device=device).unsqueeze(-1)
            else:
                edge_index_dict[key] = torch.empty((2, 0), dtype=torch.long, device=device)
                edge_weight_dict[key] = torch.empty((0, 1), dtype=torch.float, device=device)

        return edge_index_dict, edge_weight_dict

    def compute_mmd_constraint_loss(self, h_consensus_dict, h_disagreement_dict, sigma=1.0, lambda_align=1.0, lambda_conf=1.0):
        def gaussian_kernel(x, y, sigma):
            x_norm = (x ** 2).sum(dim=1, keepdim=True)
            y_norm = (y ** 2).sum(dim=1, keepdim=True)
            dist = x_norm + y_norm.t() - 2 * torch.mm(x, y.t())
            return torch.exp(-dist / (2 * sigma ** 2))
        
        def compute_mmd_squared(X, Y, sigma):
            K_XX = gaussian_kernel(X, X, sigma)
            K_YY = gaussian_kernel(Y, Y, sigma)
            K_XY = gaussian_kernel(X, Y, sigma)
            
            N, M = X.size(0), Y.size(0)
            
            term1 = (K_XX.sum() - K_XX.diag().sum()) / (N * (N - 1)) if N > 1 else torch.tensor(0.0, device=X.device)
            term2 = (K_YY.sum() - K_YY.diag().sum()) / (M * (M - 1)) if M > 1 else torch.tensor(0.0, device=Y.device)
            term3 = K_XY.mean()
            
            mmd_squared = term1 + term2 - 2 * term3
            return mmd_squared
        
        z_sim_l = h_consensus_dict['l']
        z_sim_a = h_consensus_dict['a']
        z_sim_v = h_consensus_dict['v']
        
        z_conf_l = h_disagreement_dict['l']
        z_conf_a = h_disagreement_dict['a']
        z_conf_v = h_disagreement_dict['v']
        
        align_loss = 0.0
        modality_pairs = [('l', 'a'), ('l', 'v'), ('a', 'v')]
        
        for mod1, mod2 in modality_pairs:
            z1_sim = h_consensus_dict[mod1]
            z2_sim = h_consensus_dict[mod2]
            mmd_sim = compute_mmd_squared(z1_sim, z2_sim, sigma)
            align_loss += mmd_sim
        
        align_loss = align_loss / len(modality_pairs)
        conflict_loss = 0.0
        
        for mod1, mod2 in modality_pairs:
            z1_conf = h_disagreement_dict[mod1]
            z2_conf = h_disagreement_dict[mod2]
            mmd_conf = compute_mmd_squared(z1_conf, z2_conf, sigma)
            conflict_loss += (-mmd_conf)
        
        conflict_loss = conflict_loss / len(modality_pairs)
        total_loss = lambda_align * align_loss + lambda_conf * conflict_loss
        
        return total_loss, align_loss, -conflict_loss

    def build_graphs(self, x_l, x_a, x_v):
        B = x_l.size(0)
        T_l, T_a, T_v = x_l.size(1), x_a.size(1), x_v.size(1)
        device = x_l.device


        sim_l2a_cons = self.compute_consensus_kernel(x_l, x_a, self.W_l2a_cons)
        sim_l2v_cons = self.compute_consensus_kernel(x_l, x_v, self.W_l2v_cons)
        sim_a2l_cons = self.compute_consensus_kernel(x_a, x_l, self.W_a2l_cons)
        sim_a2v_cons = self.compute_consensus_kernel(x_a, x_v, self.W_a2v_cons)
        sim_v2l_cons = self.compute_consensus_kernel(x_v, x_l, self.W_v2l_cons)
        sim_v2a_cons = self.compute_consensus_kernel(x_v, x_a, self.W_v2a_cons)

        sim_l2a_disc = self.compute_disagreement(x_l, x_a, self.W_l2a_disc, 'l', 'a')
        sim_l2v_disc = self.compute_disagreement(x_l, x_v, self.W_l2v_disc, 'l', 'v')
        sim_a2l_disc = self.compute_disagreement(x_a, x_l, self.W_a2l_disc, 'a', 'l')
        sim_a2v_disc = self.compute_disagreement(x_a, x_v, self.W_a2v_disc, 'a', 'v')
        sim_v2l_disc = self.compute_disagreement(x_v, x_l, self.W_v2l_disc, 'v', 'l')
        sim_v2a_disc = self.compute_disagreement(x_v, x_a, self.W_v2a_disc, 'v', 'a')
        
        sim_l_temp = sim_a_temp = sim_v_temp = None

        all_edges = []

        for b in range(B):
            self._process_consensus_edges(all_edges, b, 'l', 'a', sim_l2a_cons[b], T_l, T_a)
            self._process_consensus_edges(all_edges, b, 'l', 'v', sim_l2v_cons[b], T_l, T_v)
            self._process_consensus_edges(all_edges, b, 'a', 'l', sim_a2l_cons[b], T_a, T_l)
            self._process_consensus_edges(all_edges, b, 'a', 'v', sim_a2v_cons[b], T_a, T_v)
            self._process_consensus_edges(all_edges, b, 'v', 'l', sim_v2l_cons[b], T_v, T_l)
            self._process_consensus_edges(all_edges, b, 'v', 'a', sim_v2a_cons[b], T_v, T_a)

            self._process_disagreement_edges(all_edges, b, 'l', 'a', sim_l2a_disc[b], T_l, T_a)
            self._process_disagreement_edges(all_edges, b, 'l', 'v', sim_l2v_disc[b], T_l, T_v)
            self._process_disagreement_edges(all_edges, b, 'a', 'l', sim_a2l_disc[b], T_a, T_l)
            self._process_disagreement_edges(all_edges, b, 'a', 'v', sim_a2v_disc[b], T_a, T_v)
            self._process_disagreement_edges(all_edges, b, 'v', 'l', sim_v2l_disc[b], T_v, T_l)
            self._process_disagreement_edges(all_edges, b, 'v', 'a', sim_v2a_disc[b], T_v, T_a)
            
            self._process_temporal_edges(all_edges, b, 'l', sim_l_temp, T_l)
            self._process_temporal_edges(all_edges, b, 'a', sim_a_temp, T_a)
            self._process_temporal_edges(all_edges, b, 'v', sim_v_temp, T_v)

        edge_index_dict, edge_weight_dict = self._build_edge_index_from_edges(all_edges, B, T_l, T_a, T_v, device)

        return edge_index_dict, edge_weight_dict

    def _process_consensus_edges(self, all_edges, b, src_type, dst_type, sim_matrix, T_src, T_dst):
        topk_vals, topk_idx = sim_matrix.topk(self.topk, dim=-1)
        for i in range(T_src):
            for k in range(self.topk):
                if topk_vals[i, k] > self.threshold:
                    all_edges.append((
                        b, src_type, i, dst_type, topk_idx[i, k].item(),
                        topk_vals[i, k].item(),
                        'cons'
                    ))

    def _process_disagreement_edges(self, all_edges, b, src_type, dst_type, sim_matrix, T_src, T_dst):
        topk_vals, topk_idx = sim_matrix.topk(self.topk, dim=-1)
        for i in range(T_src):
            for k in range(self.topk):
                if topk_vals[i, k] > self.threshold:
                    all_edges.append((
                        b, src_type, i, dst_type, topk_idx[i, k].item(),
                        topk_vals[i, k].item(),
                        'disc'
                    ))
    
    def _process_temporal_edges(self, all_edges, b, modality_type, sim_matrix, T):
        if sim_matrix is None:
            for i in range(T - 1):
                all_edges.append((
                    b, modality_type, i, modality_type, i + 1,
                    1.0,
                    'temp'
                ))
                all_edges.append((
                    b, modality_type, i + 1, modality_type, i,
                    1.0,
                    'temp'
                ))
            return

        mask = torch.eye(T, device=sim_matrix.device).bool()
        sim_matrix_masked = sim_matrix.clone()
        sim_matrix_masked[mask] = -float('inf')
        topk_vals, topk_idx = sim_matrix_masked.topk(self.temporal_topk, dim=-1)
        for i in range(T):
            for k in range(self.temporal_topk):
                if topk_vals[i, k] > -float('inf'):
                    all_edges.append((
                        b, modality_type, i, modality_type, topk_idx[i, k].item(),
                        topk_vals[i, k].item(),
                        'temp'
                    ))





class HeterogeneousGraphNet(nn.Module):
    def __init__(self, d_l, d_a, d_v, hidden_dim, num_layers=2, edge_type='cons'):
        super().__init__()
        self.num_layers = num_layers
        self.hidden_dim = hidden_dim
        self.edge_type = edge_type

        # 投影到统一维度
        self.proj_l = nn.Linear(d_l, hidden_dim)
        self.proj_a = nn.Linear(d_a, hidden_dim)
        self.proj_v = nn.Linear(d_v, hidden_dim)

        if HAS_TORCH_GEOMETRIC:
            self.convs = nn.ModuleList([
                gnn.HeteroConv({
                    ('l', 'cons', 'a'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('l', 'cons', 'v'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('a', 'cons', 'l'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('a', 'cons', 'v'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('v', 'cons', 'l'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('v', 'cons', 'a'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('l', 'disc', 'a'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('l', 'disc', 'v'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('a', 'disc', 'l'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('a', 'disc', 'v'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('v', 'disc', 'l'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('v', 'disc', 'a'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('l', 'temp', 'l'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('a', 'temp', 'a'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                    ('v', 'temp', 'v'): gnn.GATv2Conv(hidden_dim, hidden_dim, heads=4, concat=False, add_self_loops=False, edge_dim=1),
                }, aggr='mean')
                for _ in range(num_layers)
            ])
        else:
            self.cross_modal_attn = nn.ModuleList([
                nn.ModuleDict({
                    'l2a_cons': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'l2v_cons': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'a2l_cons': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'a2v_cons': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'v2l_cons': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'v2a_cons': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'l2a_disc': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'l2v_disc': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'a2l_disc': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'a2v_disc': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'v2l_disc': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                    'v2a_disc': nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True),
                })
                for _ in range(num_layers)
            ])
            self.layer_norms = nn.ModuleList([
                nn.ModuleDict({
                    'l': nn.LayerNorm(hidden_dim),
                    'a': nn.LayerNorm(hidden_dim),
                    'v': nn.LayerNorm(hidden_dim)
                })
                for _ in range(num_layers)
            ])
        
        self.temporal_layers = nn.ModuleList([
            nn.ModuleDict({
                'l': TemporalGraphLayer(hidden_dim, num_heads=4),
                'a': TemporalGraphLayer(hidden_dim, num_heads=4),
                'v': TemporalGraphLayer(hidden_dim, num_heads=4)
                })
                for _ in range(num_layers)
            ])

        self.dropout = nn.Dropout(0.1)



    def forward(self, x_dict, edge_index_dict=None, edge_weight_dict=None, B=None, T_l=None, T_a=None, T_v=None):
        # 投影到统一维度
        x_dict['l'] = self.proj_l(x_dict['l'])
        x_dict['a'] = self.proj_a(x_dict['a'])
        x_dict['v'] = self.proj_v(x_dict['v'])

        if HAS_TORCH_GEOMETRIC and edge_index_dict is not None:
            for i in range(self.num_layers):
                conv = self.convs[i]
                if edge_weight_dict is not None:
                    x_dict = conv(x_dict, edge_index_dict, edge_attr_dict=edge_weight_dict)
                else:
                    x_dict = conv(x_dict, edge_index_dict)
                
                if i < self.num_layers - 1:
                    x_dict = {key: F.relu(self.dropout(x)) for key, x in x_dict.items()}
                
                x_l_seq = x_dict['l'].view(B, T_l, -1)
                x_a_seq = x_dict['a'].view(B, T_a, -1)
                x_v_seq = x_dict['v'].view(B, T_v, -1)
                
                temporal_layer = self.temporal_layers[i]
                x_l_seq = temporal_layer['l'](x_l_seq)
                x_a_seq = temporal_layer['a'](x_a_seq)
                x_v_seq = temporal_layer['v'](x_v_seq)
                
                x_dict['l'] = x_l_seq.reshape(-1, x_l_seq.size(-1))
                x_dict['a'] = x_a_seq.reshape(-1, x_a_seq.size(-1))
                x_dict['v'] = x_v_seq.reshape(-1, x_v_seq.size(-1))
                
        else:
            B = x_dict['l'].size(0)

            for layer_idx in range(self.num_layers):
                attn_layer = self.cross_modal_attn[layer_idx]
                norm_layer = self.layer_norms[layer_idx]

                x_l_orig = x_dict['l']
                x_a_orig = x_dict['a']
                x_v_orig = x_dict['v']

                suffix = 'cons' if self.edge_type == 'cons' else 'disc'

                l2a, _ = attn_layer[f'l2a_{suffix}'](x_dict['l'], x_dict['a'], x_dict['a'])
                l2v, _ = attn_layer[f'l2v_{suffix}'](x_dict['l'], x_dict['v'], x_dict['v'])
                new_l = (x_dict['l'] + l2a + l2v) / 3

                a2l, _ = attn_layer[f'a2l_{suffix}'](x_dict['a'], x_dict['l'], x_dict['l'])
                a2v, _ = attn_layer[f'a2v_{suffix}'](x_dict['a'], x_dict['v'], x_dict['v'])
                new_a = (x_dict['a'] + a2l + a2v) / 3

                v2l, _ = attn_layer[f'v2l_{suffix}'](x_dict['v'], x_dict['l'], x_dict['l'])
                v2a, _ = attn_layer[f'v2a_{suffix}'](x_dict['v'], x_dict['a'], x_dict['a'])
                new_v = (x_dict['v'] + v2l + v2a) / 3

                x_dict['l'] = norm_layer['l'](new_l + x_l_orig)
                x_dict['a'] = norm_layer['a'](new_a + x_a_orig)
                x_dict['v'] = norm_layer['v'](new_v + x_v_orig)

                if layer_idx < self.num_layers - 1:
                    x_dict = {key: F.relu(self.dropout(x)) for key, x in x_dict.items()}
                
                temporal_layer = self.temporal_layers[layer_idx]
                x_dict['l'] = temporal_layer['l'](x_dict['l'])
                x_dict['a'] = temporal_layer['a'](x_dict['a'])
                x_dict['v'] = temporal_layer['v'](x_dict['v'])

        return x_dict


class DualPathFusion(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.alpha = nn.Parameter(torch.tensor(0.6))
        self.gate = nn.Sequential(
            nn.Linear(dim * 2, dim),
            nn.Sigmoid()
        )
        self.confidence_predictor = nn.Sequential(
            nn.Linear(dim * 2, dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(dim // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, h_consensus, h_disagreement):
        h_static = self.alpha * h_consensus + (1 - self.alpha) * h_disagreement

        gate_weight = self.gate(torch.cat([h_consensus, h_disagreement], dim=-1))
        h_dynamic = gate_weight * h_consensus + (1 - gate_weight) * h_disagreement

        confidence = self.confidence_predictor(torch.cat([h_consensus, h_disagreement], dim=-1))

        h_basic = (h_static + h_dynamic) / 2

        h_final = confidence * h_basic + (1 - confidence) * h_consensus

        return h_final, confidence


class DisentangledRoutingFusion(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.router_mlp = nn.Sequential(
            nn.Linear(input_dim * 2, input_dim),
            nn.ReLU(),
            nn.Linear(input_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, z_cons, z_incons):
        T, B, D = z_cons.shape
        z_cons_flat = z_cons.view(T * B, D)
        z_incons_flat = z_incons.view(T * B, D)

        routing_weights_flat = self.router_mlp(torch.cat([z_cons_flat, z_incons_flat], dim=-1))
        routing_weights = routing_weights_flat.view(T, B, 1)

        fused_signal = routing_weights * z_cons + (1 - routing_weights) * z_incons

        return fused_signal, routing_weights


class ModulationModule(nn.Module):
    def __init__(self, graph_dim, original_dim):
        super().__init__()
        self.modulator_net = nn.Sequential(
            nn.Linear(graph_dim, (graph_dim + original_dim) // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear((graph_dim + original_dim) // 2, original_dim * 3)
        )
        with torch.no_grad():
            self.modulator_net[-1].bias.fill_(-3.0)

    def forward(self, temporal_intervention_signal, original_feature):
        T, B, _ = original_feature.shape
        D_graph = temporal_intervention_signal.shape[-1]

        intervention_flat = temporal_intervention_signal.view(T * B, D_graph)

        params_flat = self.modulator_net(intervention_flat)
        params = params_flat.view(T, B, -1)
        gamma, beta, gate = torch.chunk(params, 3, dim=-1)
        
        modulated_part = (torch.tanh(gamma) + 1) * original_feature + torch.tanh(beta) * 0.1
        
        gate = torch.sigmoid(gate)
        new_feature = original_feature + gate * modulated_part
        
        return new_feature


class TemporalGraphLayer(nn.Module):
    def __init__(self, input_dim, num_heads=4):
        super().__init__()
        self.attention = nn.MultiheadAttention(embed_dim=input_dim, num_heads=num_heads, batch_first=True)
        self.layer_norm = nn.LayerNorm(input_dim)
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x_res = x
        x, _ = self.attention(x, x, x)
        x = self.dropout(x)
        x = self.layer_norm(x + x_res)
        return x



    def forward(self, z_cons, z_incons):
        B, T, D = z_cons.shape

        indices = torch.randperm(T)[:2]
        t_i, t_j = indices[0], indices[1]
        
        z_i = z_cons[:, t_i, :]
        z_j = z_cons[:, t_j, :]

        sim_ij = self.cosine_similarity(z_i.unsqueeze(1), z_j.unsqueeze(0)) / self.temperature
        
        mask = torch.eye(B, device=z_cons.device).bool()
        sim_ij.masked_fill_(mask, -float('inf'))
        
        l_cohesion = -torch.mean(torch.diag(F.log_softmax(sim_ij, dim=1)))

        sim_separation = self.cosine_similarity(z_cons, z_incons)
        l_separation = torch.mean(F.relu(sim_separation - self.separation_margin))




class DynFlux(nn.Module):
    def __init__(self, args):
        super().__init__()

        if args.use_bert:
            self.text_model = BertTextEncoder(use_finetune=args.use_finetune,
                                              transformers=args.transformers,
                                              pretrained=args.pretrained)
        self.use_bert = args.use_bert

        dst_feature_dims, nheads = args.dst_feature_dim_nheads
        if args.dataset_name == 'mosi':
            self.len_l, self.len_v, self.len_a = (50, 50, 50) if args.need_data_aligned else (50, 500, 375)
        elif args.dataset_name == 'mosei':
            self.len_l, self.len_v, self.len_a = (50, 50, 50) if args.need_data_aligned else (50, 500, 500)
        else:
            raise ValueError(f"Unknown dataset {args.dataset_name}")

        self.aligned = args.need_data_aligned
        self.orig_d_l, self.orig_d_a, self.orig_d_v = args.feature_dims
        self.d_l = self.d_a = self.d_v = dst_feature_dims
        self.num_heads = nheads
        self.layers = args.nlevels
        self.attn_dropout, self.attn_dropout_a, self.attn_dropout_v = args.attn_dropout, args.attn_dropout_a, args.attn_dropout_v
        self.relu_dropout, self.embed_dropout, self.res_dropout = args.relu_dropout, args.embed_dropout, args.res_dropout
        self.output_dropout, self.text_dropout = args.output_dropout, args.text_dropout
        self.attn_mask = args.attn_mask
        self.fusion_method = args.fusion_method
        output_dim = 1
        self.args = args

        self.use_graph_branch = getattr(args, 'use_graph_branch', True)
        if self.use_graph_branch:
            self.graph_hidden_dim = getattr(args, 'graph_hidden_dim', self.d_l)
        else:
            self.graph_hidden_dim = 0

        self.proj_l = nn.Conv1d(self.orig_d_l, self.d_l, kernel_size=args.conv1d_kernel_size_l, padding=0, bias=False)
        self.proj_a = nn.Conv1d(self.orig_d_a, self.d_a, kernel_size=args.conv1d_kernel_size_a, padding=0, bias=False)
        self.proj_v = nn.Conv1d(self.orig_d_v, self.d_v, kernel_size=args.conv1d_kernel_size_v, padding=0, bias=False)

        self.encoder_l = nn.Conv1d(self.d_l, self.d_l, kernel_size=1, padding=0, bias=False)
        self.encoder_v = nn.Conv1d(self.d_v, self.d_v, kernel_size=1, padding=0, bias=False)
        self.encoder_a = nn.Conv1d(self.d_a, self.d_a, kernel_size=1, padding=0, bias=False)

        self.self_attentions_l = self._build_transformer('l')
        self.self_attentions_v = self._build_transformer('v')
        self.self_attentions_a = self._build_transformer('a')

        if self.use_graph_branch:
            self.pool_l = GuidedAttentionPool(self.d_l, self.graph_hidden_dim)
            self.pool_a = GuidedAttentionPool(self.d_a, self.graph_hidden_dim)
            self.pool_v = GuidedAttentionPool(self.d_v, self.graph_hidden_dim)
        else:
            # 使用标准注意力池化
            self.pool_l = AttentionPool(self.d_l)
            self.pool_a = AttentionPool(self.d_a)
            self.pool_v = AttentionPool(self.d_v)



        if self.use_graph_branch:
            graph_topk = getattr(args, 'graph_topk', 5)
            graph_threshold = getattr(args, 'graph_threshold', 0.3)
            graph_num_layers = getattr(args, 'graph_num_layers', 2)

            disc_mode = getattr(args, 'disc_mode', 'orc')
            self.graph_builder = ConsensusDisagreementGraphBuilder(
                self.d_l, self.d_a, self.d_v,
                topk=graph_topk, threshold=graph_threshold, disc_mode=disc_mode
            )

            self.consensus_gnn = HeterogeneousGraphNet(
                self.d_l, self.d_a, self.d_v,
                hidden_dim=self.graph_hidden_dim,
                num_layers=graph_num_layers,
                edge_type='cons'
            )

            self.disagreement_gnn = HeterogeneousGraphNet(
                self.d_l, self.d_a, self.d_v,
                hidden_dim=self.graph_hidden_dim,
                num_layers=graph_num_layers,
                edge_type='disc'
            )

            # 双通路融合
            self.dual_path_fusion = DualPathFusion(graph_hidden_dim)

            self.drf_fusion = DisentangledRoutingFusion(graph_hidden_dim)



            self.graph_pool_l = AttentionPool(graph_hidden_dim)
            self.graph_pool_a = AttentionPool(graph_hidden_dim)
            self.graph_pool_v = AttentionPool(graph_hidden_dim)

            self.modulator_l = ModulationModule(self.graph_hidden_dim, self.d_l)
            self.modulator_a = ModulationModule(self.graph_hidden_dim, self.d_a)
            self.modulator_v = ModulationModule(self.graph_hidden_dim, self.d_v)
            
            self.fusion_modulator_l = None
            self.fusion_modulator_a = None
            self.fusion_modulator_v = None
            
            self.fusion_weight_modulator = FusionWeightModulator(self.graph_hidden_dim, num_modalities=3)


        else:
            self.graph_hidden_dim = 0

        self.proj1_l = nn.Linear(self.d_l, self.d_l); self.proj2_l = nn.Linear(self.d_l, self.d_l)
        self.out_layer_l = nn.Linear(self.d_l, output_dim)

        self.proj1_v = nn.Linear(self.d_l, self.d_l); self.proj2_v = nn.Linear(self.d_l, self.d_l)
        self.out_layer_v = nn.Linear(self.d_l, output_dim)

        self.proj1_a = nn.Linear(self.d_l, self.d_l); self.proj2_a = nn.Linear(self.d_l, self.d_l)
        self.out_layer_a = nn.Linear(self.d_l, output_dim)

        fuse_in = self.d_l if self.fusion_method == "sum" else self.d_l * 3
        if self.use_graph_branch:
            self.final_fusion_dim = fuse_in + self.graph_hidden_dim * 3
        else:
            self.final_fusion_dim = fuse_in

        self.proj1_c = nn.Linear(self.final_fusion_dim, self.final_fusion_dim)
        self.proj2_c = nn.Linear(self.final_fusion_dim, self.final_fusion_dim)
        self.out_layer_c = nn.Linear(self.final_fusion_dim, output_dim)

        if self.final_fusion_dim != self.d_l:
            self.proj_c_distill = nn.Sequential(
                nn.Linear(self.final_fusion_dim, (self.final_fusion_dim + self.d_l) // 2),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear((self.final_fusion_dim + self.d_l) // 2, self.d_l)
            )
        else:
            # 维度相同时，使用恒等映射
            self.proj_c_distill = nn.Identity()

        # Router & 对齐
        flat_dim = self.orig_d_l * self.len_l + self.orig_d_a * self.len_l + self.orig_d_v * self.len_l
        self.Router = router(flat_dim, 3, self.args.temperature)
        self.transfer_a_ali = nn.Linear(self.len_a, self.len_l)
        self.transfer_v_ali = nn.Linear(self.len_v, self.len_l)

        # ===== ESD/ORC 超参（可解释损失与不一致构建） =====
        self.esd_m_pos = getattr(args, 'esd_m_pos', 0.3)
        self.esd_m_neg = getattr(args, 'esd_m_neg', 0.3)
        self.esd_tau_res = getattr(args, 'esd_tau_res', 1.0)
        self.disc_rank_ratio = getattr(args, 'disc_rank_ratio', 0.5)

    # ───────────────────────
    def _modulate_fusion_weights(self, original_weights, temporal_intervention_l, temporal_intervention_a, temporal_intervention_v):
        """
        使用时序干预信号对Router生成的融合权重进行调制
        
        Args:
            original_weights: (B, 3) - Router生成的原始权重
            temporal_intervention_l, a, v: (T, B, D_graph) - 三个模态的时序干预信号
        
        Returns:
            modulated_weights: (B, 3) - 调制后的融合权重
            weight_conf: (B, 1) - 权重调制置信度
        """
        if self.use_graph_branch and hasattr(self, 'fusion_weight_modulator'):
            temporal_signals = [temporal_intervention_l, temporal_intervention_a, temporal_intervention_v]
            modulated_weights, weight_conf = self.fusion_weight_modulator(original_weights, temporal_signals)
            return modulated_weights, weight_conf
        else:
            # 如果未启用图分支，返回原始权重
            return original_weights, None

    # ───────────────────────
    def _build_transformer(self, t):
        if t == 'l':   embed_dim, attn_dropout = self.d_l, self.attn_dropout
        elif t == 'a': embed_dim, attn_dropout = self.d_a, self.attn_dropout_a
        else:          embed_dim, attn_dropout = self.d_v, self.attn_dropout_v
        
        # ===== 新增：传递干预维度 =====
        intervention_dim = self.graph_hidden_dim if self.use_graph_branch else None
        
        return TransformerEncoder(embed_dim=embed_dim,
                                  num_heads=self.num_heads,
                                  layers=self.layers,
                                  attn_dropout=attn_dropout,
                                  relu_dropout=self.relu_dropout,
                                  res_dropout=self.res_dropout,
                                  embed_dropout=self.embed_dropout,
                                  attn_mask=self.attn_mask,
                                  intervention_dim=intervention_dim)

    # ───────────────────────
    def _safe_transformer_forward(self, transformer, x):
        """安全的Transformer前向传播，避免重复调用"""
        result = transformer(x)
        if isinstance(result, tuple):
            return result[0]
        return result

    # ───────────────────────
    def _mlp_head(self, x, p1, p2, out):
        h = p2(F.dropout(F.relu(p1(x), inplace=True),
                         p=self.output_dropout, training=self.training))
        h = h + x
        return out(h), h

    # ───────────────────────
    def _process_graph_branch(self, x_l_seq, x_a_seq, x_v_seq):
        """处理图分支 - 时空图架构：GNN中已包含时序信息
        x_l_seq: (B, T_l, D_l)
        x_a_seq: (B, T_a, D_a)
        x_v_seq: (B, T_v, D_v)
        
        Returns:
            graph_l, graph_a, graph_v: 池化后的图特征 (B, D_graph)
            conf_l, conf_a, conf_v: 置信度 (B, 1)
            temporal_intervention_l, temporal_intervention_a, temporal_intervention_v: 时序干预信号 (T, B, D_graph)
            z_consensus/disagreement_*: 时序增强特征用于损失计算
        """
        B = x_l_seq.size(0)
        T_l, T_a, T_v = x_l_seq.size(1), x_a_seq.size(1), x_v_seq.size(1)

        if HAS_TORCH_GEOMETRIC:
            # 构建时空图：包含跨模态边（共识/分歧）和时序边
            edge_all, weight_all = self.graph_builder.build_graphs(x_l_seq, x_a_seq, x_v_seq)

            # 拆分边索引字典和边权重字典
            cons_eidx = {k: v for k, v in edge_all.items() if k[1] == 'cons'}
            disc_eidx = {k: v for k, v in edge_all.items() if k[1] == 'disc'}
            cons_with_temp = {k: v for k, v in edge_all.items() if k[1] in ['cons','temp']}
            disc_with_temp = {k: v for k, v in edge_all.items() if k[1] in ['disc','temp']}
            cons_weights = {k: v for k, v in weight_all.items() if k[1] in ['cons','temp']}
            disc_weights = {k: v for k, v in weight_all.items() if k[1] in ['disc','temp']}

            # 准备图数据
            x_dict = {
                'l': x_l_seq.reshape(-1, x_l_seq.size(-1)),  # (B*T_l, D_l)
                'a': x_a_seq.reshape(-1, x_a_seq.size(-1)),  # (B*T_a, D_a)
                'v': x_v_seq.reshape(-1, x_v_seq.size(-1))   # (B*T_v, D_v)
            }

            # 分别处理共识图和分歧图（GNN层与时序层交替在 HeterogeneousGraphNet 内部）
            h_consensus_dict = self.consensus_gnn(
                x_dict.copy(), cons_with_temp, cons_weights, B=B, T_l=T_l, T_a=T_a, T_v=T_v
            )
            # 分歧网络
            h_disagreement_dict = self.disagreement_gnn(
                x_dict.copy(), disc_with_temp, disc_weights, B=B, T_l=T_l, T_a=T_a, T_v=T_v
            )

            # 在(B*T, D)空间计算“签名边一致性”损失（共识边应相似，分歧边应相反）



            
            # 计算 MMD 约束损失
            mmd_total_loss, mmd_align_loss, mmd_conflict_loss = self.graph_builder.compute_mmd_constraint_loss(
                h_consensus_dict, h_disagreement_dict, sigma=1.0, lambda_align=1.0, lambda_conf=1.0
            )

            # 重塑回序列格式 (B*T, D) -> (T, B, D)
            h_consensus_l = h_consensus_dict['l'].view(B, T_l, -1).permute(1, 0, 2)
            h_consensus_a = h_consensus_dict['a'].view(B, T_a, -1).permute(1, 0, 2)
            h_consensus_v = h_consensus_dict['v'].view(B, T_v, -1).permute(1, 0, 2)

            h_disagreement_l = h_disagreement_dict['l'].view(B, T_l, -1).permute(1, 0, 2)
            h_disagreement_a = h_disagreement_dict['a'].view(B, T_a, -1).permute(1, 0, 2)
            h_disagreement_v = h_disagreement_dict['v'].view(B, T_v, -1).permute(1, 0, 2)
            
        else:
            # 替代实现：保持批维度，避免跨样本污染
            # 同样构建图以获得边集合
            edge_all, weight_all = self.graph_builder.build_graphs(x_l_seq, x_a_seq, x_v_seq)
            cons_eidx = {k: v for k, v in edge_all.items() if k[1] == 'cons'}
            disc_eidx = {k: v for k, v in edge_all.items() if k[1] == 'disc'}

            x_dict = {
                'l': x_l_seq,  # (B, T_l, D_l)
                'a': x_a_seq,  # (B, T_a, D_a)
                'v': x_v_seq   # (B, T_v, D_v)
            }

            # 分别处理共识和分歧（内部已包含时序处理）
            h_consensus_dict = self.consensus_gnn(x_dict.copy())

            # 分歧网络
            h_disagreement_dict = self.disagreement_gnn(x_dict.copy())

            # 将(B,T,D)展平成(B*T,D)以适配全局索引边
            def flatten_bt(x, T):
                B = x.size(0)
                return x.reshape(B*T, -1)
            flat_cons = { 'l': flatten_bt(h_consensus_dict['l'], T_l),
                          'a': flatten_bt(h_consensus_dict['a'], T_a),
                          'v': flatten_bt(h_consensus_dict['v'], T_v) }
            flat_disc = { 'l': flatten_bt(h_disagreement_dict['l'], T_l),
                          'a': flatten_bt(h_disagreement_dict['a'], T_a),
                          'v': flatten_bt(h_disagreement_dict['v'], T_v) }

            # 计算 MMD 约束损失
            mmd_total_loss, mmd_align_loss, mmd_conflict_loss = self.graph_builder.compute_mmd_constraint_loss(
                flat_cons, flat_disc, sigma=1.0, lambda_align=1.0, lambda_conf=1.0
            )



            # 转换格式 (B, T, D) -> (T, B, D)
            h_consensus_l = h_consensus_dict['l'].permute(1, 0, 2)
            h_consensus_a = h_consensus_dict['a'].permute(1, 0, 2)
            h_consensus_v = h_consensus_dict['v'].permute(1, 0, 2)

            h_disagreement_l = h_disagreement_dict['l'].permute(1, 0, 2)
            h_disagreement_a = h_disagreement_dict['a'].permute(1, 0, 2)
            h_disagreement_v = h_disagreement_dict['v'].permute(1, 0, 2)

        # 注意：由于GNN内部已经进行了时序处理，这里的特征已经是时空融合的特征
        # 我们直接使用这些特征，不再需要额外的时序层
        z_consensus_l = h_consensus_l
        z_consensus_a = h_consensus_a
        z_consensus_v = h_consensus_v
        
        z_disagreement_l = h_disagreement_l
        z_disagreement_a = h_disagreement_a
        z_disagreement_v = h_disagreement_v

        # ===== 使用解耦路由融合 (DRF) 生成干预信号 =====
        # DRF会返回融合后的信号以及用于分析的路由权重
        temporal_intervention_l, routing_weights_l = self.drf_fusion(z_consensus_l, z_disagreement_l)
        temporal_intervention_a, routing_weights_a = self.drf_fusion(z_consensus_a, z_disagreement_a)
        temporal_intervention_v, routing_weights_v = self.drf_fusion(z_consensus_v, z_disagreement_v)
        
        # 池化
        consensus_l_pool = self.graph_pool_l(z_consensus_l)
        consensus_a_pool = self.graph_pool_a(z_consensus_a)
        consensus_v_pool = self.graph_pool_v(z_consensus_v)

        disagreement_l_pool = self.graph_pool_l(z_disagreement_l)
        disagreement_a_pool = self.graph_pool_a(z_disagreement_a)
        disagreement_v_pool = self.graph_pool_v(z_disagreement_v)

        # 双通路融合（带置信门控）
        graph_l, conf_l = self.dual_path_fusion(consensus_l_pool, disagreement_l_pool)
        graph_a, conf_a = self.dual_path_fusion(consensus_a_pool, disagreement_a_pool)
        graph_v, conf_v = self.dual_path_fusion(consensus_v_pool, disagreement_v_pool)

        # ===== 新增：反射器对齐约束 =====
        # 目的: 强制反射器学习一个有意义的“反向”变换，使其输出与共识特征对立
        # (B, T, D) -> (T, B, D)
        # 反射器对齐约束已移除，因为反射现在在消息传递中进行


        return (graph_l, graph_a, graph_v, conf_l, conf_a, conf_v,
                temporal_intervention_l, temporal_intervention_a, temporal_intervention_v,
                z_consensus_l, z_consensus_a, z_consensus_v,
                z_disagreement_l, z_disagreement_a, z_disagreement_v,
                routing_weights_l, routing_weights_a, routing_weights_v,
                mmd_total_loss, mmd_align_loss, mmd_conflict_loss)

    # ───────────────────────
    def forward(self, text, audio, video):
        # 1) 文本编码
        if self.use_bert:
            text = self.text_model(text)                    # (B,T,768)

        # 2) 转置为 (B,C,L)
        x_l = F.dropout(text.transpose(1, 2), p=self.text_dropout, training=self.training)
        x_a = audio.transpose(1, 2)
        x_v = video.transpose(1, 2)

        # 3) 若非对齐，插值
        if not self.aligned:
            audio_ = self.transfer_a_ali(audio.permute(0,2,1)).permute(0,2,1)
            video_ = self.transfer_v_ali(video.permute(0,2,1)).permute(0,2,1)
            m_i = torch.cat((text, video_, audio_), dim=2)
        else:
            m_i = torch.cat((text, video, audio), dim=2)
        m_w = self.Router(m_i)                               # (B,3)

        # 4) Conv1d 投影
        proj_x_l = x_l if self.orig_d_l == self.d_l else self.proj_l(x_l)
        proj_x_a = x_a if self.orig_d_a == self.d_a else self.proj_a(x_a)
        proj_x_v = x_v if self.orig_d_v == self.d_v else self.proj_v(x_v)

        # 保存序列格式用于图分支
        x_l_seq = proj_x_l.permute(0, 2, 1)  # (B, T_l, D_l)
        x_a_seq = proj_x_a.permute(0, 2, 1)  # (B, T_a, D_a)
        x_v_seq = proj_x_v.permute(0, 2, 1)  # (B, T_v, D_v)

        # 5) 1×1 Conv - 使用模态特定编码器
        c_l = self.encoder_l(proj_x_l);  c_l = c_l.permute(2,0,1)   # (L,B,D)
        c_a = self.encoder_a(proj_x_a);  c_a = c_a.permute(2,0,1)
        c_v = self.encoder_v(proj_x_v);  c_v = c_v.permute(2,0,1)

        # 6) Transformer - 使用安全前向传播
        c_l_att = self._safe_transformer_forward(self.self_attentions_l, c_l)
        c_a_att = self._safe_transformer_forward(self.self_attentions_a, c_a)
        c_v_att = self._safe_transformer_forward(self.self_attentions_v, c_v)

        # ────────────  图分支处理与全流程因果监督  ────────────
        # 初始化所有变量，确保在任何情况下都有默认值
        graph_l = graph_a = graph_v = None
        conf_l = conf_a = conf_v = None
        temporal_intervention_l = temporal_intervention_a = temporal_intervention_v = None
        routing_weights_l = routing_weights_a = routing_weights_v = None
        
        if self.use_graph_branch:
            # 获取图分支的所有输出，包括时序干预信号和时序增强特征
            (graph_l, graph_a, graph_v, conf_l, conf_a, conf_v,
             temporal_intervention_l, temporal_intervention_a, temporal_intervention_v,
             z_consensus_l, z_consensus_a, z_consensus_v,
             z_disagreement_l, z_disagreement_a, z_disagreement_v,
             routing_weights_l, routing_weights_a, routing_weights_v,
             mmd_total_loss, mmd_align_loss, mmd_conflict_loss) = self._process_graph_branch(x_l_seq, x_a_seq, x_v_seq)

            # ===== 第1层干预：微观干预 - Transformer内部调制 =====
            # 使用时序干预信号对序列特征进行逐时间步调制
            c_l_att = self.modulator_l(temporal_intervention_l, c_l_att)
            c_a_att = self.modulator_a(temporal_intervention_a, c_a_att)
            c_v_att = self.modulator_v(temporal_intervention_v, c_v_att)

        # 7) Attention Pooling → (B,D) - 第2层干预：中观干预
        if self.use_graph_branch and temporal_intervention_l is not None:
            # 使用指导性注意力池化，接受时序干预信号
            c_l_att = self.pool_l(c_l_att, temporal_intervention_l)
            c_a_att = self.pool_a(c_a_att, temporal_intervention_a)
            c_v_att = self.pool_v(c_v_att, temporal_intervention_v)
        else:
            # 使用标准注意力池化
            c_l_att = self.pool_l(c_l_att)
            c_a_att = self.pool_a(c_a_att)
            c_v_att = self.pool_v(c_v_att)




        # ===== 第3层干预：宏观干预 - 融合前最终调制 =====
        # 第3层宏观干预（融合前最终调制）已移除，不再对池化后的单模态特征进行调制

        # 8) 单模态 MLP
        logits_l, l_proj = self._mlp_head(c_l_att, self.proj1_l, self.proj2_l, self.out_layer_l)
        logits_v, v_proj = self._mlp_head(c_v_att, self.proj1_v, self.proj2_v, self.out_layer_v)
        logits_a, a_proj = self._mlp_head(c_a_att, self.proj1_a, self.proj2_a, self.out_layer_a)

        # ===== 第4层干预：融合权重调制 =====
        # 使用时序干预信号对Router生成的权重进行智能调整
        weight_modulation_conf = None
        if self.use_graph_branch:
            m_w_modulated, weight_modulation_conf = self._modulate_fusion_weights(
                m_w, temporal_intervention_l, temporal_intervention_a, temporal_intervention_v
            )
        else:
            m_w_modulated = m_w

        # 9) 融合原始分支 - 使用调制后的权重
        if self.fusion_method == "sum":
            c_fusion = (c_l_att * m_w_modulated[:, 0:1] +
                        c_v_att * m_w_modulated[:, 1:2] +
                        c_a_att * m_w_modulated[:, 2:3])
        else:  # concat
            c_fusion = torch.cat([c_l_att * m_w_modulated[:, 0:1],
                                  c_v_att * m_w_modulated[:, 1:2],
                                  c_a_att * m_w_modulated[:, 2:3]], dim=-1) * 3

        # 10) 融合图分支特征（如果启用）
        if self.use_graph_branch:
            graph_fusion = torch.cat([graph_l, graph_a, graph_v], dim=-1)
            # 最终融合：原始分支 + 图分支
            final_fusion = torch.cat([c_fusion, graph_fusion], dim=-1)
        else:
            final_fusion = c_fusion

        # 11) 最终预测
        # 计算完整的投影
        c_proj_full = self.proj2_c(F.dropout(F.relu(self.proj1_c(final_fusion), inplace=True),
                                             p=self.output_dropout, training=self.training))
        c_proj_full = c_proj_full + final_fusion
        logits_c = self.out_layer_c(c_proj_full)

        # 生成用于蒸馏的投影（与单模态维度匹配）
        # 从完整投影中提取与单模态维度匹配的特征
        c_proj_for_distill = self.proj_c_distill(c_proj_full)

        # 为了保持向后兼容，c_proj仍然返回用于蒸馏的版本
        # 但也提供完整版本c_proj_full供其他用途

        # 12) 输出
        output_dict = {
            'logits_c': logits_c,
            'logits_l': logits_l,
            'logits_v': logits_v,
            'logits_a': logits_a,
            'channel_weight': m_w,  # 原始Router权重
            'channel_weight_modulated': m_w_modulated if self.use_graph_branch else m_w,  # 调制后的权重
            'c_proj': c_proj_for_distill,  # 用于蒸馏损失（与l_proj/v_proj/a_proj维度匹配）
            'c_proj_full': c_proj_full,    # 完整的高维投影
            'l_proj': l_proj,
            'v_proj': v_proj,
            'a_proj': a_proj,
            'c_fea': final_fusion,  # 融合后的特征
            # 图分支输出（如果未启用则为None）
            'graph_l': graph_l if self.use_graph_branch else None,
            'graph_a': graph_a if self.use_graph_branch else None,
            'graph_v': graph_v if self.use_graph_branch else None,
            # 双通路融合置信度输出
            'conf_l': conf_l if self.use_graph_branch else None,
            'conf_a': conf_a if self.use_graph_branch else None,
            'conf_v': conf_v if self.use_graph_branch else None,

            # 融合权重调制置信度输出
            'weight_modulation_conf': weight_modulation_conf if self.use_graph_branch else None,
            # 时序干预信号（用于分析和可视化）
            'temporal_intervention_l': temporal_intervention_l if self.use_graph_branch else None,
            'temporal_intervention_a': temporal_intervention_a if self.use_graph_branch else None,
            'temporal_intervention_v': temporal_intervention_v if self.use_graph_branch else None,
            # 新增：路由权重（用于分析和可视化）
            'routing_weights_l': routing_weights_l if self.use_graph_branch else None,
            'routing_weights_a': routing_weights_a if self.use_graph_branch else None,
            'routing_weights_v': routing_weights_v if self.use_graph_branch else None,
            # MMD 约束损失（基于论文方法的投影矩阵约束）
            'mmd_total_loss': mmd_total_loss if self.use_graph_branch else None,
            'mmd_align_loss': mmd_align_loss if self.use_graph_branch else None,
            'mmd_conflict_loss': mmd_conflict_loss if self.use_graph_branch else None,
        }



        return output_dict